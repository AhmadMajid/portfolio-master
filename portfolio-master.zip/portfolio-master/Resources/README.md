This folder contains all resource files that will be downloaded upon request.
